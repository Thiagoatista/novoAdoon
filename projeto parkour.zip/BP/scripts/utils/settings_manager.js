import { world, system, ItemStack } from '@minecraft/server';

const settings = new Map();
const DEFAULT_SETTINGS = {
    land_dash: { enabled: true, name: "parkour.setting.land_dash" },
    aqua_dash: { enabled: true, name: "parkour.setting.aqua_dash" },
    slide: { enabled: true, name: "parkour.setting.slide" },
    crawl: { enabled: true, name: "parkour.setting.crawl" },
    air_jump: { enabled: true, name: "parkour.setting.air_jump" }, 
    air_jump_old: { enabled: true, name: "parkour.setting.air_jump_old" }, 
    jump_fence: { enabled: true, name: "parkour.setting.jump_fence" },
    grab: { enabled: true, name: "parkour.setting.grab" },
    wall_slide: { enabled: false, name: "parkour.setting.wall_slide" },
    footstep: { enabled: true, name: "parkour.setting.footstep" },
    debuff: { enabled: true, level: 50, name: "parkour.setting.debuff" }
};

export const SettingsManager = {
    load: name => {
        try {
            const saved = world.getDynamicProperty(`parkour:settings_${name}`);
            if (typeof saved === "string" && saved) {
                const parsed = JSON.parse(saved);
                let updated = false;
                // Preenche automaticamente chaves novas (como 'footstep') em saves antigos
                for (const key in DEFAULT_SETTINGS) {
                    if (!parsed[key]) {
                        parsed[key] = JSON.parse(JSON.stringify(DEFAULT_SETTINGS[key]));
                        updated = true;
                    }
                }
                settings.set(name, parsed);
                if (updated) SettingsManager.save(name);
            } else {
                settings.set(name, JSON.parse(JSON.stringify(DEFAULT_SETTINGS)));
            }
        } catch (error) {
            console.warn(`[Parkour] Falha ao carregar configurações de ${name}: ${error}`);
            settings.set(name, JSON.parse(JSON.stringify(DEFAULT_SETTINGS)));
        }
    },
    save: name => {
        const s = settings.get(name);
        if (s) world.setDynamicProperty(`parkour:settings_${name}`, JSON.stringify(s));
    },
    get: name => {
        if (!settings.has(name)) SettingsManager.load(name);
        return settings.get(name);
    },
    enabled: (name, move) => {
        const s = SettingsManager.get(name);
        return s[move]?.enabled ?? true;
    },
    
    toggle: (name, move) => {
        const s = SettingsManager.get(name);
        if (!s[move]) {
            s[move] = JSON.parse(JSON.stringify(DEFAULT_SETTINGS[move] || { enabled: true }));
        }
        s[move].enabled = !s[move].enabled;
        SettingsManager.save(name);
        return s[move].enabled;
    },

    set: (name, move, value) => {
        const s = SettingsManager.get(name);
        if (!s[move]) {
            s[move] = JSON.parse(JSON.stringify(DEFAULT_SETTINGS[move] || { enabled: value }));
        }
        s[move].enabled = value;
        SettingsManager.save(name);
    },

    setLevel: (name, move, value) => {
        const s = SettingsManager.get(name);
        if (!s[move]) {
            s[move] = JSON.parse(JSON.stringify(DEFAULT_SETTINGS[move] || { level: value }));
        }
        s[move].level = value;
        SettingsManager.save(name);
    },

    getAll: () => Object.keys(DEFAULT_SETTINGS),
    getStatus: name => {
        const s = SettingsManager.get(name);
        return Object.fromEntries(Object.keys(DEFAULT_SETTINGS).map(m => [m, {
            enabled: s[m]?.enabled ?? DEFAULT_SETTINGS[m].enabled,
            level: s[m]?.level ?? DEFAULT_SETTINGS[m].level,
            name: DEFAULT_SETTINGS[m].name
        }]));
    }
};

world.afterEvents.playerSpawn.subscribe(e => {
    const player = e.player;

    if (!settings.has(player.name)) SettingsManager.load(player.name);

    if (e.initialSpawn && !player.hasTag("parkour_config_received")) {
        system.run(() => {
            try {
                const inv = player.getComponent("minecraft:inventory")?.container;
                if (inv) {
                    const item = new ItemStack("parkour:settings", 1);
                    item.keepOnDeath = true;
                    inv.addItem(item);
                    
                    player.addTag("parkour_config_received");
                }
            } catch (error) {
                console.warn(`[Parkour] Falha ao entregar o item de configurações para ${player.name}: ${error}`);
            }
        });
    }
});

world.afterEvents.playerLeave.subscribe(event => {
    settings.delete(event.playerName);
});
