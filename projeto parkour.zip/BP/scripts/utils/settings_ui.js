import { world, system, EquipmentSlot } from '@minecraft/server';
import { ModalFormData } from '@minecraft/server-ui';
import { SettingsManager } from './settings_manager.js';

const SETTINGS_ITEM_ID = 'parkour:settings'; 

world.afterEvents.itemUse.subscribe((event) => {
    const item = event.itemStack;
    const player = event.source;

    if (item.typeId === SETTINGS_ITEM_ID) {
        if (!item.keepOnDeath) {
            system.run(() => {
                const equip = player.getComponent("minecraft:equippable");
                if (equip) {
                    const handItem = equip.getEquipment(EquipmentSlot.Mainhand);
                    if (handItem && handItem.typeId === SETTINGS_ITEM_ID) {
                        handItem.keepOnDeath = true;
                        equip.setEquipment(EquipmentSlot.Mainhand, handItem);
                    }
                }
            });
        }

        showSettingsMenu(player);
    }
});

// A FUNÇÃO QUE TINHA SUMIDO ESTÁ AQUI DE VOLTA!
function showSettingsMenu(player) {
    const settings = SettingsManager.getStatus(player.name);
    const moves = SettingsManager.getAll();

    const form = new ModalFormData();
    form.title({ translate: "parkour.ui.title" });
    
    const formMap = {};
    let componentIndex = 0;

    moves.forEach(move => {
        form.toggle(
            { translate: settings[move].name },
            { defaultValue: settings[move].enabled }
        );
        formMap[move] = { toggleIdx: componentIndex++ };
        
        if (move === 'debuff') {
            form.slider(
                { translate: "parkour.setting.debuff_level" },
                20,
                80,
                { valueStep: 5, defaultValue: settings[move].level }
            );
            formMap[move].sliderIdx = componentIndex++;
        }
    });

    form.submitButton({ translate: "parkour.ui.save" });
    
    system.run(async () => {
        try {
            const response = await form.show(player);
            if (!response.canceled && response.formValues) {
                let changed = false;

                moves.forEach((move) => {
                    const toggleVal = response.formValues[formMap[move].toggleIdx];
                    if (toggleVal !== settings[move].enabled) {
                        SettingsManager.set(player.name, move, toggleVal);
                        changed = true;
                        
                        const statusColor = toggleVal ? "§aON" : "§cOFF";
                        player.sendMessage({
                            rawtext: [
                                { text: "§a[Parkour] §f" },
                                { translate: settings[move].name },
                                { text: `: ${statusColor}` }
                            ]
                        });
                    }

                    if (move === 'debuff') {
                        const sliderVal = response.formValues[formMap[move].sliderIdx];
                        if (sliderVal !== settings[move].level) {
                            SettingsManager.setLevel(player.name, move, sliderVal);
                            changed = true;
                            
                            player.sendMessage({
                                rawtext: [
                                    { text: "§a[Parkour] §f" },
                                    { translate: "parkour.setting.debuff_level" },
                                    { text: `: §e${sliderVal}` }
                                ]
                            });
                        }
                    }
                });
                
                if (!changed) {
                    player.sendMessage({ translate: "parkour.chat.no_change" });
                }
            }
        } catch (e) {
            console.warn(`[Parkour] Falha ao abrir ou salvar o menu de configurações: ${e}`);
        }
    });
}
