import { world, system, EquipmentSlot } from "@minecraft/server";
// Importação do scanner unificado
import { BlockScanner } from "../utils/abilities_scanners.js";

const FOOT_OFFSET = 0.12;
const PARTICLE_Y_OFFSET = 0.1;

const nextLeftZap = new Map();
const nextRightZap = new Map();

function getZapRandomTicks() {
    return Math.floor(Math.random() * 46) + 25;
}

world.afterEvents.playerLeave.subscribe((ev) => {
    nextLeftZap.delete(ev.playerId);
    nextRightZap.delete(ev.playerId);
});

system.runInterval(() => {
    const tick = system.currentTick;

    for (const player of world.getPlayers()) {
        if (!player.isValid()) continue;

        const equip = player.getComponent("minecraft:equippable");
        if (!equip) continue;

        const feet = equip.getEquipment(EquipmentSlot.Feet);
        if (feet && feet.typeId === "parkour:gold_boot_velocity") {
            
            player.addEffect("speed", 40, { amplifier: 1, showParticles: false });

            const vel = player.getVelocity();
            const speed = Math.hypot(vel.x, vel.z);
            const isTravado = player.hasTag("parkour_travado") || player.hasTag("parkour_wall_sliding");

            if (!isTravado) {
                handleRandomZaps(player, tick);
            } else {
                nextLeftZap.delete(player.id);
                nextRightZap.delete(player.id);
            }

            // Usando o scanner centralizado para checar água no pé
            const inWater = BlockScanner.scan(player, tick, { needSpectralWaterCheck: true }).spectralWaterCheck;

            if (!player.isOnGround || inWater) continue; 
            
            if (speed > 0.05) {
                spawnFootstepParticles(player, tick, speed); 
            }
        }
    }
});

function handleRandomZaps(player, tick) {
    const playerId = player.id;

    if (!nextLeftZap.has(playerId)) nextLeftZap.set(playerId, tick + getZapRandomTicks());
    if (!nextRightZap.has(playerId)) nextRightZap.set(playerId, tick + getZapRandomTicks());

    const doLeftZap = tick >= nextLeftZap.get(playerId);
    const doRightZap = tick >= nextRightZap.get(playerId);

    if (!doLeftZap && !doRightZap) return;

    const loc = player.location;
    const viewDir = player.getViewDirection();
    const horizontalLen = Math.hypot(viewDir.x, viewDir.z);
    let rightX = 0;
    let rightZ = 0;

    if (horizontalLen > 0.001) {
        rightX = (-viewDir.z) / horizontalLen;
        rightZ = (viewDir.x) / horizontalLen;
    } else {
        rightX = 1;
        rightZ = 0;
    }

    if (doLeftZap) {
        const spawnX = loc.x - (rightX * FOOT_OFFSET);
        const spawnZ = loc.z - (rightZ * FOOT_OFFSET);
        try { player.dimension.spawnParticle("parkour:zap_boots", { x: spawnX, y: loc.y + PARTICLE_Y_OFFSET, z: spawnZ }); } catch(e){}
        nextLeftZap.set(playerId, tick + getZapRandomTicks()); 
    }

    if (doRightZap) {
        const spawnX = loc.x + (rightX * FOOT_OFFSET);
        const spawnZ = loc.z + (rightZ * FOOT_OFFSET);
        try { player.dimension.spawnParticle("parkour:zap_boots", { x: spawnX, y: loc.y + PARTICLE_Y_OFFSET, z: spawnZ }); } catch(e){}
        nextRightZap.set(playerId, tick + getZapRandomTicks()); 
    }
}

function spawnFootstepParticles(player, tick, speed) {
    let isLeftStep = false;
    let isRightStep = false;

    if (speed > 0.28) {
        isLeftStep = tick % 4 === 0;
        isRightStep = tick % 4 === 2;
    } 
    else if (speed > 0.15) {
        isLeftStep = tick % 8 === 0;
        isRightStep = tick % 8 === 4;
    }
    else {
        isLeftStep = tick % 16 === 0;
        isRightStep = tick % 16 === 8;
    }

    if (!isLeftStep && !isRightStep) return;

    const loc = player.location;
    const viewDir = player.getViewDirection();
    const horizontalLen = Math.hypot(viewDir.x, viewDir.z);
    let rightX = 0;
    let rightZ = 0;

    if (horizontalLen > 0.001) {
        rightX = (-viewDir.z) / horizontalLen;
        rightZ = (viewDir.x) / horizontalLen;
    } else {
        rightX = 1;
        rightZ = 0;
    }

    let spawnX = loc.x;
    let spawnZ = loc.z;

    if (isLeftStep) {
        spawnX -= rightX * FOOT_OFFSET;
        spawnZ -= rightZ * FOOT_OFFSET;
    } else {
        spawnX += rightX * FOOT_OFFSET;
        spawnZ += rightZ * FOOT_OFFSET;
    }

    const particleLoc = { x: spawnX, y: loc.y + PARTICLE_Y_OFFSET, z: spawnZ };

    try {
        player.dimension.spawnParticle("parkour:zap_boots_splash", particleLoc);
    } catch (e) {}
}

